declare namespace Express {
    export interface Request {
        cartao_id: string;
    }
}